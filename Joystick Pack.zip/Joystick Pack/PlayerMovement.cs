﻿using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

// [주의] using UnityEngine.InputSystem; 네임스페이스는 조이스틱 에셋을 사용하면 필요 없습니다. (제거됨)

public class PlayerMovement : MonoBehaviour
{
    [Header("1. 이동 설정")]
    public float moveSpeed = 5.0f;

    [Header("2. 타일맵 충돌/통과 설정")]
    public Tilemap Roadmap; // 적 길목 (Tilemap Collider 2D, Is Trigger 체크 해제)
    public Tilemap Bridge;  // 통과 가능한 타일 (Tilemap Collider 2D 없음)
    public LayerMask pathLayer; // Roadmap에 할당된 'Path' 레이어 마스크

    [Header("3. 순간이동 설정")]
    // 이 값을 Roadmap의 폭(타일 유닛)에 맞게 Inspector에서 설정해야 합니다.
    public float teleportDistance = 5.0f;

    [Header("조이스틱 설정")]
    // Inspector에서 Hierarchy의 조이스틱 오브젝트를 할당해야 합니다. (필수)
    public FloatingJoystick joystick;


    private Rigidbody2D rb;
    private Vector2 movementInput;
    // BoxCast 충돌 감지 신뢰도를 높이기 위한 아주 작은 여유 공간
    private const float CAST_BUFFER = 0.01f;
    private bool isTeleportingFlag = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("Rigidbody2D 컴포넌트가 플레이어 오브젝트에 없습니다.");
        }
        rb.freezeRotation = true;
    }

    void Update()
    {
        // =======================================================
        // ✨ 수정된 부분: 키보드 입력 대신 조이스틱 입력 사용
        // =======================================================
        if (joystick != null)
        {
            float moveX = joystick.Horizontal;
            float moveY = joystick.Vertical;
            movementInput = new Vector2(moveX, moveY).normalized;
        }
        else
        {
            // 조이스틱 할당이 누락되었거나 찾을 수 없을 경우를 대비 (디버깅용)
            // WASD 테스트를 유지하고 싶다면 이곳에 키보드 입력 코드를 남겨둡니다.
            movementInput = Vector2.zero;
        }
    }

    void FixedUpdate()
    {
        // ⚠️ 순간이동 직후 프레임에서는 이동을 건너뛰어 안정성을 확보합니다.
        if (isTeleportingFlag)
        {
            isTeleportingFlag = false;
            return;
        }

        // 이동 입력이 없으면 정지
        if (movementInput.sqrMagnitude == 0) return;

        // 설정 확인 (로직 안정화)
        if (Roadmap == null || Bridge == null || pathLayer == 0)
        {
            rb.MovePosition(rb.position + movementInput * moveSpeed * Time.fixedDeltaTime);
            return;
        }

        Collider2D playerCollider = GetComponent<Collider2D>();
        if (playerCollider == null) return;

        // 이동할 거리와 방향 계산
        float moveDistance = moveSpeed * Time.fixedDeltaTime;
        Vector2 movementVector = movementInput.normalized;

        // BoxCast 설정
        Vector2 boxSize = playerCollider.bounds.size;
        float castDistance = moveDistance + CAST_BUFFER;

        // 1. 이동 경로 상에 'Path' 레이어(Roadmap)와 충돌하는지 BoxCast로 검사
        RaycastHit2D hit = Physics2D.BoxCast(
            rb.position,
            boxSize,
            0f,
            movementVector,
            castDistance,
            pathLayer
        );

        // 기본 목표 위치 (충돌이 없을 경우)
        Vector2 finalPosition = rb.position + movementVector * moveDistance;

        // 2. 충돌이 감지된 경우 (Roadmap에 닿음)
        if (hit.collider != null)
        {
            // Roadmap 충돌체가 맞는지 확인
            if (hit.collider.gameObject == Roadmap.gameObject)
            {
                // 충돌 지점 근처의 월드 위치를 계산하여 Bridge 타일맵의 셀을 확인
                Vector2 checkPosition = rb.position + (Vector2)(movementVector * (hit.distance - CAST_BUFFER / 2f));
                Vector3Int cellPosition = Bridge.WorldToCell(checkPosition);

                // 3. 해당 좌표에 Bridge 타일이 '존재'하는지 확인합니다.
                TileBase bridgeTile = Bridge.GetTile(cellPosition);

                // ------------------ 디버깅 로그 ------------------
                Debug.Log($"⛔️ 충돌 감지됨! 타겟 셀: {cellPosition}");
                Debug.Log($"   Bridge 타일 존재 여부: {bridgeTile != null}");
                // ------------------------------------------------

                // 4. Bridge 타일이 존재한다면 순간이동 로직을 실행합니다.
                if (bridgeTile != null)
                {
                    Vector2 teleportDirection = -movementVector; // 이동 방향의 반대
                    Vector2 teleportTarget = rb.position + teleportDirection * teleportDistance;

                    Debug.Log($"✅ Bridge 타일 존재. 순간이동 실행! 목표: {teleportTarget}");

                    // 💥 순간이동 실행: Rigidbody의 위치를 직접 설정
                    rb.position = teleportTarget;

                    // 다음 프레임에서 FixedUpdate 진입 시 이동을 막기 위해 플래그 설정
                    isTeleportingFlag = true;

                    // 순간이동을 실행했으므로, 현재 프레임에서 추가 이동은 막습니다.
                    return;
                }
                else
                {
                    // 5. Bridge 타일이 없으므로 충돌 지점 바로 앞에서 멈춥니다.
                    float stopDistance = hit.distance - CAST_BUFFER;
                    if (stopDistance > 0)
                    {
                        finalPosition = rb.position + movementVector * stopDistance;
                    }
                    else
                    {
                        finalPosition = rb.position;
                    }
                    Debug.Log($"❌ Bridge 타일 없음. 이동 불가. 정지 위치: {finalPosition}");
                }
            }
        }

        // 6. 최종 계산된 위치로 Rigidbody를 이동
        rb.MovePosition(finalPosition);
    }

    // ----------------------------------------------------
    // Bridge 타일 동적 생성/제거 함수
    // ----------------------------------------------------

    public void SetBridgeTile(Vector3 worldPosition, TileBase tileToSet)
    {
        if (Bridge != null)
        {
            Vector3Int cellPos = Bridge.WorldToCell(worldPosition);
            Bridge.SetTile(cellPos, tileToSet);
            Debug.Log($"Bridge 타일 상태 변경됨: {cellPos}, 타일: {tileToSet != null}");
        }
    }
}