using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;     // ���� ��� (�÷��̾�)
    public float smoothSpeed = 5f; // ī�޶� �̵� �ε巯��
    public Vector3 offset;       // ī�޶� ��ġ ������

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desiredPosition = target.position + offset;
        Vector3 smoothedPosition = Vector3.Lerp(
            transform.position,
            desiredPosition,
            smoothSpeed * Time.deltaTime
        );

        transform.position = smoothedPosition;
    }
}
